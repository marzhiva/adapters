package com.example.myapplication1111.fragments

import androidx.fragment.app.Fragment
import com.example.myapplication1111.R

class SecondFragment:Fragment(R.layout.fragment_second) {
}